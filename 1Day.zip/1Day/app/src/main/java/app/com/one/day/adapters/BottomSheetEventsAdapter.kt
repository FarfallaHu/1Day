package app.com.one.day.adapters

import android.content.Context
import android.graphics.Paint
import android.os.AsyncTask
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import app.com.one.day.R
import app.com.one.day.models.EventEntityModel
import app.com.one.day.utils.DatabaseClient


class BottomSheetEventsAdapter(
    val eventList: ArrayList<EventEntityModel>,
    val context: Context
) :
    RecyclerView.Adapter<BottomSheetEventsAdapter.DisplayerViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DisplayerViewHolder {
        val itemView =
            LayoutInflater.from(parent.context)
                .inflate(R.layout.sheet_event_layout_row, parent, false)
        return DisplayerViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: DisplayerViewHolder, position: Int) {
        val event = eventList[position]
        holder.tvEventName.text = event.name
        holder.tvEventTime.text = event.startTime + " - " + event.endTime

        if (event.isFinished) {
            holder.tvEventName.paintFlags =
                holder.tvEventName.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            holder.checkBox.isChecked = true
        }

        holder.checkBox.setOnClickListener {
            val updateEvent = UpdateEvent()
            if ((it as CheckBox).isChecked) {
                holder.tvEventName.paintFlags =
                    holder.tvEventName.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG

                val updatedEvent = EventEntityModel()
                updatedEvent.isFinished = true
                updatedEvent.id = event.id
                updateEvent.execute(updatedEvent)
            } else {
                holder.tvEventName.paintFlags =
                    holder.tvEventName.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()

                val updatedEvent = EventEntityModel()
                updatedEvent.isFinished = false
                updatedEvent.id = event.id
                updateEvent.execute(updatedEvent)
            }
        }

    }

    inner class UpdateEvent() : AsyncTask<EventEntityModel?, Void?, Void?>() {

        override fun onPostExecute(aVoid: Void?) {
            super.onPostExecute(aVoid)
        }

        override fun doInBackground(vararg params: EventEntityModel?): Void? {
            val event = params[0] as EventEntityModel
            //adding to database
            DatabaseClient.getInstance(context).appDatabase
                .eventDao()
                .update(
                    event.isFinished,
                    event.id
                )
            return null
        }
    }

    override fun getItemCount(): Int {
        return eventList.size
    }

    class DisplayerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tvEventName: TextView = itemView.findViewById<View>(R.id.tv_eventName) as TextView
        var tvEventTime: TextView = itemView.findViewById<View>(R.id.tv_eventDate) as TextView
        var checkBox: CheckBox = itemView.findViewById<View>(R.id.cb_event) as CheckBox
    }
}