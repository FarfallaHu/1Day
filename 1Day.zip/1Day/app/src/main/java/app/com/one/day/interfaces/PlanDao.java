package app.com.one.day.interfaces;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

import app.com.one.day.models.PlanEntityModel;

@Dao
public interface PlanDao {

    @Query("SELECT * FROM PlanEntityModel")
    List<PlanEntityModel> getAllPlans();

    @Query("SELECT * FROM PlanEntityModel where name = :name")
    List<PlanEntityModel> getSpecificPlan(String name);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(PlanEntityModel plan);

    @Delete
    void delete(PlanEntityModel plan);
}