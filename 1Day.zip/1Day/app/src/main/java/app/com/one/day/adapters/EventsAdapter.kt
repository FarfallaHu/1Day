package app.com.one.day.adapters

import android.content.Context
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import app.com.one.day.R
import app.com.one.day.models.EventEntityModel

class EventsAdapter(
    val eventList: ArrayList<EventEntityModel>,
    val context: Context
) :
    RecyclerView.Adapter<EventsAdapter.DisplayerViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DisplayerViewHolder {
        val itemView =
            LayoutInflater.from(parent.context).inflate(R.layout.event_layout_row, parent, false)
        return DisplayerViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: DisplayerViewHolder, position: Int) {
        val event = eventList[position]
        holder.tvEventName.text = event.name
        holder.tvEventDesc.text = event.description
        holder.tvEventDate.text = event.date
        holder.tvEventPlan.text = event.plan
        holder.tvEventTime.text = event.startTime + " - " + event.endTime
        holder.tvEventIcon.text = event.name.toString().substring(0, 1).toUpperCase()
        when (event.color) {
            "Blue" -> {
                holder.tvEventIcon.backgroundTintList =
                    ContextCompat.getColorStateList(context, R.color.blue)
            }
            "Green" -> {
                holder.tvEventIcon.backgroundTintList =
                    ContextCompat.getColorStateList(context, R.color.green)
            }
            "Yellow" -> {
                holder.tvEventIcon.backgroundTintList =
                    ContextCompat.getColorStateList(context, R.color.yellow)
            }
            "Red" -> {
                holder.tvEventIcon.backgroundTintList =
                    ContextCompat.getColorStateList(context, R.color.red)
            }
            "Pink" -> {
                holder.tvEventIcon.backgroundTintList =
                    ContextCompat.getColorStateList(context, R.color.pink)
            }
        }
    }

    override fun getItemCount(): Int {
        return eventList.size
    }

    class DisplayerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tvEventName: TextView = itemView.findViewById<View>(R.id.tv_eventTitle) as TextView
        var tvEventDate: TextView = itemView.findViewById<View>(R.id.tv_eventDate) as TextView
        var tvEventPlan: TextView = itemView.findViewById<View>(R.id.tv_plan) as TextView
        var tvEventTime: TextView = itemView.findViewById<View>(R.id.tv_eventTime) as TextView
        var tvEventDesc: TextView = itemView.findViewById<View>(R.id.tv_desc) as TextView
        var tvEventIcon: TextView = itemView.findViewById<View>(R.id.tv_eventIcon) as TextView
    }
}