package app.com.one.day.views.activities

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.app.DatePickerDialog.OnDateSetListener
import android.app.TimePickerDialog
import android.content.SharedPreferences
import android.os.Bundle
import android.text.method.TextKeyListener.clear
import android.view.View
import android.widget.AdapterView
import app.com.one.day.R
import app.com.one.day.databinding.ActivityCreateEventBinding
import app.com.one.day.models.EventEntityModel
import app.com.one.day.models.PlanEntityModel
import app.com.one.day.utils.SharePrefData
import java.util.*


class CreateEventActivity : BaseActivity<ActivityCreateEventBinding>() {
    lateinit var calendar: Calendar
    lateinit var startTimePicker: TimePickerDialog
    lateinit var endTimePicker: TimePickerDialog

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bindView(R.layout.activity_create_event)
        supportActionBar?.hide()

        calendar = Calendar.getInstance();
        checkPref()
        binding?.spinnerPlans?.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {

                }

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    if (parent?.selectedItem?.equals("Other") == true) {
                        binding?.layoutPlan?.visibility = View.VISIBLE
                    } else {
                        binding?.layoutPlan?.visibility = View.GONE
                    }
                }

            }

        binding?.btnCreateEvent?.setOnClickListener {
            if (validateForm()) {
                clearPref()
                val event = EventEntityModel()
                event.name = binding?.edEventName?.text?.toString()
                event.date = binding?.edEventDate?.text?.toString()
                event.startTime = binding?.edStartTime?.text?.toString()
                event.endTime = binding?.edEndTime?.text?.toString()
                if (binding?.spinnerPlans?.selectedItem?.equals("Other") == true) {
                    event.plan = binding?.edPlan?.text?.toString()
                } else {
                    event.plan = binding?.spinnerPlans?.selectedItem?.toString()
                }
                event.color = binding?.spinnerColor?.selectedItem?.toString()
                event.description = binding?.edMessage?.text?.toString()
                event.isFinished = false

                val plan = PlanEntityModel()
                plan.name = event.plan

                val savePlan = SavePlan()
                savePlan.execute(plan)

                val saveEvent = SaveEvent()
                saveEvent.execute(event)
            }
        }

        val date =
            OnDateSetListener { view, year, monthOfYear, dayOfMonth ->
                calendar.set(Calendar.YEAR, year)
                calendar.set(Calendar.MONTH, monthOfYear)
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)

                val date: String = dateFormat.format(calendar.time)

                binding?.edEventDate?.setText(date)
            }


        binding?.edEventDate?.setOnClickListener() {
            DatePickerDialog(
                this@CreateEventActivity, date, calendar
                    .get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        binding?.ivBack?.setOnClickListener {
            finish()
        }

        binding?.tvSaveDraft?.setOnClickListener {
            val sharePrefData = SharePrefData.getInstance()
            sharePrefData.setPrefBoolean(this, "EventData", true)
            sharePrefData.setPrefString(this, "name", binding?.edEventName?.text?.toString())
            sharePrefData.setPrefString(this, "date", binding?.edEventDate?.text?.toString())
            sharePrefData.setPrefString(this, "startTime", binding?.edStartTime?.text?.toString())
            sharePrefData.setPrefString(this, "endTime", binding?.edEndTime?.text?.toString())

            sharePrefData.setPrefString(
                this,
                "desc",
                binding?.edMessage?.text.toString()
            )

            finish()

        }

        binding?.edStartTime?.setOnClickListener {
            val mcurrentTime = Calendar.getInstance()
            val hour = mcurrentTime[Calendar.HOUR_OF_DAY]
            val minute = mcurrentTime[Calendar.MINUTE]
            startTimePicker = TimePickerDialog(
                this@CreateEventActivity,
                { timePicker, selectedHour, selectedMinute ->
                    binding?.edStartTime?.setText("$selectedHour:$selectedMinute")
                    startTimePicker.dismiss()
                },
                hour,
                minute,
                false
            ) //Yes 24 hour time
            startTimePicker.show()
        }

        binding?.edEndTime?.setOnClickListener {
            val mcurrentTime = Calendar.getInstance()
            val hour = mcurrentTime[Calendar.HOUR_OF_DAY]
            val minute = mcurrentTime[Calendar.MINUTE]
            endTimePicker = TimePickerDialog(
                this@CreateEventActivity,
                { timePicker, selectedHour, selectedMinute ->
                    binding?.edEndTime?.setText("$selectedHour:$selectedMinute")
                    endTimePicker.dismiss()
                },
                hour,
                minute,
                false
            ) //Yes 24 hour time
            endTimePicker.show()
        }


    }

    private fun clearPref() {
        val sharePrefData = SharePrefData.getInstance()
        sharePrefData.clearSharedPreferences(this, "EventData")
        sharePrefData.clearSharedPreferences(this, "name")
        sharePrefData.clearSharedPreferences(this, "desc")
        sharePrefData.clearSharedPreferences(this, "date")
        sharePrefData.clearSharedPreferences(this, "startTime")
        sharePrefData.clearSharedPreferences(this, "endTime")
    }

    private fun checkPref() {
        val sharePrefData = SharePrefData.getInstance()
        if (sharePrefData.containsPrefData(this, "EventData")) {
            binding?.edEventName?.setText(
                sharePrefData.getPrefString(
                    this@CreateEventActivity,
                    "name"
                )
            )
            binding?.edEventDate?.setText(
                sharePrefData.getPrefString(
                    this@CreateEventActivity,
                    "date"
                )
            )
            binding?.edStartTime?.setText(
                sharePrefData.getPrefString(
                    this@CreateEventActivity,
                    "startTime"
                )
            )
            binding?.edEndTime?.setText(
                sharePrefData.getPrefString(
                    this@CreateEventActivity,
                    "endTime"
                )
            )
            binding?.edMessage?.setText(
                sharePrefData.getPrefString(
                    this@CreateEventActivity,
                    "desc"
                )
            )
        }
    }

    private fun validateForm(): Boolean {
        if (binding?.edEventName?.text.toString().isEmpty()) {
            showToast("Event name cannot be empty!")
            return false
        } else if (binding?.edEventDate?.text.toString().isEmpty()) {
            showToast("Event date cannot be empty!")
            return false
        } else if (binding?.edStartTime?.text.toString().isEmpty()) {
            showToast("Start time cannot be empty!")
            return false
        } else if (binding?.edEndTime?.text.toString().isEmpty()) {
            showToast("End time cannot be empty!")
            return false
        } else {
            return true
        }
    }
}