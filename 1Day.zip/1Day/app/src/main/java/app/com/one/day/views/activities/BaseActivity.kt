package app.com.one.day.views.activities

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.Fragment
import app.com.one.day.R
import app.com.one.day.models.EventEntityModel
import app.com.one.day.models.PlanEntityModel
import app.com.one.day.utils.DatabaseClient
import app.com.one.day.utils.LoadingDialogFragment
import app.com.one.day.viewmodels.BaseViewModel
import com.google.android.material.snackbar.Snackbar
import java.text.SimpleDateFormat
import java.util.*


abstract class BaseActivity<Binding : ViewDataBinding> : AppCompatActivity() {

    public var binding: Binding? = null

    var mCurrentFragment: Fragment? = null
    private val GRANT_ALL_PERMISSIONS = 100
    lateinit var dateFormat: SimpleDateFormat
    var baseViewModel: BaseViewModel? = null
    private val loadingDialogFragment by lazy { LoadingDialogFragment() }
    var permissions = arrayOf(
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.WRITE_EXTERNAL_STORAGE,
        Manifest.permission.CAMERA
    )
    var mProgressDialog: android.app.AlertDialog? = null
    protected fun bindView(layoutId: Int) {
        binding = DataBindingUtil.setContentView<Binding>(this, layoutId)

    }

    protected fun setScreenLayoutParams(blueLayout: LinearLayout) {
        supportActionBar?.hide()
        val layoutParams =
            blueLayout.getLayoutParams()
        val metrics = resources.displayMetrics
        val DeviceTotalHeight = metrics.heightPixels * 30 / 100
        layoutParams?.height = DeviceTotalHeight
        blueLayout.layoutParams = layoutParams
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dateFormat = SimpleDateFormat("dd-MM-yyyy")

    }

    fun checkPermission() {
        ActivityCompat.requestPermissions(
            this,
            permissions,
            GRANT_ALL_PERMISSIONS
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String?>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == GRANT_ALL_PERMISSIONS) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d("Permissions", "Permissions Granted")
            } else {
                showToast("Permission cannot be granted")
            }
        }
    }

    @JvmOverloads
    fun showHideProgress(
        show: Boolean,
        progressMessage: String? = "Please Wait"
    ) {

        if (show) {
            if (!loadingDialogFragment.isAdded) {
                loadingDialogFragment.addFragmentOnlyOnce(supportFragmentManager, "loader")
            }
        } else {
            if (loadingDialogFragment.isAdded) {
                loadingDialogFragment.dismissAllowingStateLoss()
            }
        }
    }

    fun showAlertDialog(dialogTitle: String?, message: String?) {
        val builder = android.app.AlertDialog.Builder(this)
        builder.setMessage(message).setTitle(dialogTitle)
        builder.setCancelable(false)
            .setPositiveButton(
                "Ok"
            ) { dialog, id -> dialog.dismiss() }
        val alert = builder.create()
        alert.setTitle(dialogTitle)
        alert.setOnShowListener {
            alert.getButton(AlertDialog.BUTTON_POSITIVE)
                .setTextColor(resources?.getColor(R.color.purple_700)!!)
        }
        alert.show()
    }

    fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    fun closeKeyboard() {
        val inputManager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        if (this.currentFocus != null) inputManager.hideSoftInputFromWindow(
            this.currentFocus!!.windowToken, InputMethodManager.RESULT_UNCHANGED_SHOWN
        )
    }

    open fun showKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0)
    }

    fun isKeyboardOpen(): Boolean {
        val inputManager =
            applicationContext.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

        return inputManager.isAcceptingText
    }

    override fun onBackPressed() {
        performBackStackManagement()
    }

    fun performBackStackManagement() {
        val fm = supportFragmentManager
        if (fm.backStackEntryCount == 1) {
            finish()
        } else {
            val index = supportFragmentManager.backStackEntryCount - 2
            if (index >= 0) {
                val backEntry = supportFragmentManager.getBackStackEntryAt(index)
                val tag = backEntry.name
                mCurrentFragment = supportFragmentManager.findFragmentByTag(tag)

                showHideFragment(mCurrentFragment!!)
            }
            super.onBackPressed()
        }
    }

    fun finishAllFragmentsExceptFirstOne() {
        var manager = supportFragmentManager
        if (manager.backStackEntryCount > 1) {
            for (i in 0 until manager.backStackEntryCount - 1) {
                manager.popBackStack()
            }

            val backEntry = supportFragmentManager.getBackStackEntryAt(0)
            val tag = backEntry.name
            mCurrentFragment = supportFragmentManager.findFragmentByTag(tag)

            showHideFragment(mCurrentFragment!!)
        }
    }

    fun showHideFragment(fragment: Fragment) {
        val manager = supportFragmentManager

        val t = manager.beginTransaction()
        for (i in 0 until manager.fragments.size) {
            val f = manager.fragments[i]
            t.hide(f)
        }
        t.show(fragment).commit()
    }

    fun replaceFragment(fragment: Fragment) {
        val frag = Fragment()

        if (mCurrentFragment != null && mCurrentFragment!!::class.java.equals(
                fragment::class.java
            )
        ) {

            return
        }
        val manager = supportFragmentManager
        mCurrentFragment = fragment

        try {

            val t = manager.beginTransaction()
            val currentFrag = manager.findFragmentByTag(fragment::class.java.simpleName)

            if (fragment.isAdded) {
                //                manager.popBackStackImmediate(fragment::class.java.simpleName, 0)
                t.remove(frag).commit();
                return
            }

            if (currentFrag != null && currentFrag::class.java.simpleName.equals(
                    fragment::class.java.simpleName
                )
            ) {
                showHideFragment(currentFrag)
                manager.popBackStackImmediate(mCurrentFragment!!::class.java.simpleName, 1)
            }
            t.add(R.id.container, fragment, fragment::class.java.simpleName)
                .addToBackStack(fragment::class.java.simpleName).commit()


        } catch (e: Exception) {
            Log.e("ex", "repalceFrag funcation Exception in base Activity ")
            val t = manager.beginTransaction()
            t.add(R.id.container, fragment, fragment::class.java.simpleName)
                .addToBackStack(fragment::class.java.simpleName).commit()


        }
        showHideFragment(fragment)
    }


    open fun generateRandomID(): String? {
        val AlphaNumericString = "0123456789"
        val sb = StringBuilder(50)
        for (i in 0..14) {
            val index = (AlphaNumericString.length * Math.random()).toInt()
            sb.append(
                AlphaNumericString[index]
            )
        }
        return sb.toString()
    }

    fun getCurrentDate(): String {
        val c = Calendar.getInstance().time
        return dateFormat.format(c)
    }


    fun setObservers(baseViewModel: BaseViewModel, baseActivity: BaseActivity<*>) {

        this.baseViewModel = baseViewModel
        try {
            baseViewModel.dialogLiveData.observe(this, {
//                showHideProgress(it, "")
            })
            baseViewModel.dialogLiveData.observe(this, {
                Log.d("errrorscreen", baseActivity::class.java.name + " Screen")
            })
        } catch (ex: java.lang.Exception) {
            var i: Int
        }
    }

    inner class SavePlan : AsyncTask<PlanEntityModel?, Void?, Void?>() {

        override fun onPostExecute(aVoid: Void?) {
            super.onPostExecute(aVoid)
        }

        override fun doInBackground(vararg params: PlanEntityModel?): Void? {
            val plan = params[0] as PlanEntityModel
            //adding to database
            DatabaseClient.getInstance(applicationContext).appDatabase
                .plansDao()
                .insert(plan)
            return null
        }
    }

    inner class SaveEvent : AsyncTask<EventEntityModel?, Void?, Void?>() {

        override fun onPostExecute(aVoid: Void?) {
            super.onPostExecute(aVoid)
            Toast.makeText(applicationContext, "Event Created", Toast.LENGTH_LONG).show()
            finish()
        }

        override fun doInBackground(vararg params: EventEntityModel?): Void? {
            val event = params[0] as EventEntityModel
            //adding to database
            DatabaseClient.getInstance(applicationContext).appDatabase
                .eventDao()
                .insert(event)
            return null
        }
    }

    inner class GetAllPlans() : AsyncTask<String?, Void?, List<PlanEntityModel>>() {
        override fun onPostExecute(tasks: List<PlanEntityModel>) {
            super.onPostExecute(tasks)
            baseViewModel?.plansLiveData?.postValue(tasks)
        }

        override fun doInBackground(vararg params: String?): List<PlanEntityModel> {
            return DatabaseClient
                .getInstance(applicationContext)
                .appDatabase
                .plansDao()
                .allPlans
        }
    }

    inner class GetAllEvents() : AsyncTask<String?, Void?, List<EventEntityModel>>() {
        override fun onPostExecute(tasks: List<EventEntityModel>) {
            super.onPostExecute(tasks)
            baseViewModel?.eventsLiveData?.postValue(tasks)
        }

        override fun doInBackground(vararg params: String?): List<EventEntityModel> {
            return DatabaseClient
                .getInstance(applicationContext)
                .appDatabase
                .eventDao()
                .allEvents
        }
    }

    inner class GetDateBasedEvents() : AsyncTask<String?, Void?, List<EventEntityModel>>() {
        override fun onPostExecute(tasks: List<EventEntityModel>) {
            super.onPostExecute(tasks)
            baseViewModel?.eventsLiveData?.postValue(tasks)
        }

        override fun doInBackground(vararg params: String?): List<EventEntityModel> {
            var date = params[0] as String
            return DatabaseClient
                .getInstance(applicationContext)
                .appDatabase
                .eventDao()
                .getDateBasedEvents(date)
        }
    }

    inner class DeletePlan : AsyncTask<EventEntityModel?, Void?, Void?>() {

        override fun onPostExecute(aVoid: Void?) {
            super.onPostExecute(aVoid)
            Toast.makeText(applicationContext, "Deleted", Toast.LENGTH_LONG).show()
        }

        override fun doInBackground(vararg params: EventEntityModel?): Void? {
            val event = params[0] as EventEntityModel
            //adding to database
            DatabaseClient.getInstance(applicationContext).appDatabase
                .eventDao()
                .delete(event)
            return null
        }
    }
}