package app.com.one.day.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import app.com.one.day.models.EventEntityModel
import app.com.one.day.models.GenericValidationModel
import app.com.one.day.models.PlanEntityModel

abstract class BaseViewModel(application: Application) : AndroidViewModel(application) {


    var validationLiveDate = MutableLiveData<GenericValidationModel>()
        protected set
    var dialogLiveData = MutableLiveData<Boolean>()
        protected set
    var backPressLiveData = MutableLiveData<Boolean>()
        protected set

    var plansLiveData = MutableLiveData<List<PlanEntityModel>>()
        protected set

    var eventsLiveData = MutableLiveData<List<EventEntityModel>>()
        protected set

    var errorLiveData = MutableLiveData<GenericValidationModel>()
        protected set

    fun onBackPressed() {
        backPressLiveData.postValue(true)
    }
}