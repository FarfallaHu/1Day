package app.com.one.day.utils

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.AsyncTask
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import app.com.one.day.R
import app.com.one.day.adapters.BottomSheetEventsAdapter
import app.com.one.day.adapters.EventsAdapter
import app.com.one.day.models.EventEntityModel
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class BottomSheetFragment : BottomSheetDialogFragment() {
    lateinit var recyclerView: RecyclerView
    lateinit var tvNoEventCreated: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun setupDialog(dialog: Dialog, style: Int) {
        val contentView = View.inflate(context, R.layout.bottom_sheet_layout, null)
        dialog.setContentView(contentView)
        recyclerView = contentView.findViewById(R.id.rv_events)
        tvNoEventCreated = contentView.findViewById(R.id.no_event_found)
        val eventName = contentView.findViewById<TextView>(R.id.textView)
        val done = contentView.findViewById<TextView>(R.id.tv_done)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        dialog.setCanceledOnTouchOutside(false)
        eventName.text = plan
        done.setOnClickListener {
            dialog.dismiss()
        }

        val getAllEvents = GetAllEvents()
        getAllEvents.execute()
    }

    inner class GetAllEvents() : AsyncTask<String?, Void?, List<EventEntityModel>>() {
        override fun onPostExecute(tasks: List<EventEntityModel>) {
            super.onPostExecute(tasks)
            if (tasks.isEmpty()) {
                recyclerView.visibility = View.GONE
                tvNoEventCreated.visibility = View.VISIBLE
            } else {
                recyclerView.layoutManager =
                    LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false)
                val adapter =
                    BottomSheetEventsAdapter(tasks as ArrayList<EventEntityModel>, activity!!)
                recyclerView.adapter = adapter
            }
        }

        override fun doInBackground(vararg params: String?): List<EventEntityModel> {
            return DatabaseClient
                .getInstance(activity)
                .appDatabase
                .eventDao()
                .getSpecificPlanEvents(plan)
        }
    }

    companion object {
        var plan = ""
        fun newInstance(planName: String): BottomSheetFragment {
            this.plan = planName
            return BottomSheetFragment()
        }
    }
}