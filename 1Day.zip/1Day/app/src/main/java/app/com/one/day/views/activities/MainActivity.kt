package app.com.one.day.views.activities

import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import app.com.one.day.R
import app.com.one.day.adapters.EventsAdapter
import app.com.one.day.adapters.PlansAdapter
import app.com.one.day.databinding.ActivityMainBinding
import app.com.one.day.models.EventEntityModel
import app.com.one.day.models.PlanEntityModel
import app.com.one.day.viewmodels.MainViewModel
import com.michalsvec.singlerowcalendar.calendar.CalendarChangesObserver
import com.michalsvec.singlerowcalendar.calendar.CalendarViewManager
import com.michalsvec.singlerowcalendar.calendar.SingleRowCalendar
import com.michalsvec.singlerowcalendar.calendar.SingleRowCalendarAdapter
import com.michalsvec.singlerowcalendar.selection.CalendarSelectionManager
import com.michalsvec.singlerowcalendar.utils.DateUtils
import java.util.*
import kotlin.collections.ArrayList


class MainActivity : BaseActivity<ActivityMainBinding>() {

    private val calendar = Calendar.getInstance()
    private var currentMonth = 0
    lateinit var rvPlan: RecyclerView
    lateinit var viewModel: MainViewModel
    var eventsList: ArrayList<EventEntityModel> = ArrayList()
    lateinit var eventAdapter: EventsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bindView(R.layout.activity_main)
        supportActionBar?.hide()
        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)
        binding?.dashboardActivity = viewModel
        setObservers(viewModel, this)
        setObservers()
        calendar.time = Date()
        currentMonth = calendar[Calendar.MONTH]
        initializaCalendar()
        rvPlan = findViewById(R.id.rv_plan)
        initPlanAdapter()
        initEventsAdapter()

        binding?.btnCreateEvent?.setOnClickListener {
            val intent = Intent(this@MainActivity, CreateEventActivity::class.java)
            startActivity(intent)
        }
    }

    private fun initPlanAdapter() {
        val getEvents = GetAllPlans()
        getEvents.execute()
    }

    private fun setObservers() {
        viewModel.plansLiveData.observe(this, {
            val list = it as ArrayList<PlanEntityModel>
            if (list.isEmpty()) {
                binding?.rvPlan?.visibility = View.GONE
                binding?.noPlanFound?.visibility = View.VISIBLE
            } else {
                binding?.rvPlan?.visibility = View.VISIBLE
                binding?.noPlanFound?.visibility = View.GONE

                rvPlan.layoutManager =
                    LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
                val adapter = PlansAdapter(list, this@MainActivity)
                rvPlan.adapter = adapter
            }
        })

        viewModel.eventsLiveData.observe(this, {
            eventsList = it as ArrayList<EventEntityModel>
            binding?.rvEvents?.layoutManager =
                LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
            val dividerItemDecoration = DividerItemDecoration(
                this,
                DividerItemDecoration.VERTICAL
            )
            if (eventsList.isEmpty()) {
                binding?.rvEvents?.visibility = View.GONE
                binding?.noEventFound?.visibility = View.VISIBLE
            } else {
                binding?.rvEvents?.visibility = View.VISIBLE
                binding?.noEventFound?.visibility = View.GONE

                binding?.rvEvents?.addItemDecoration(dividerItemDecoration)
                eventAdapter = EventsAdapter(eventsList, this)
                binding?.rvEvents?.adapter = eventAdapter
            }
        })

        val deleteEventTouchHelperCallback: ItemTouchHelper.SimpleCallback =
            object : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT) {
                private val background = ColorDrawable(Color.RED)
                override fun onMove(
                    recyclerView: RecyclerView,
                    viewHolder: RecyclerView.ViewHolder,
                    target: RecyclerView.ViewHolder
                ): Boolean {
                    return false
                }

                override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                    val position = viewHolder.adapterPosition
                    showConfirmationDialog(position)
                }

                override fun onChildDraw(
                    c: Canvas,
                    recyclerView: RecyclerView,
                    viewHolder: RecyclerView.ViewHolder,
                    dX: Float,
                    dY: Float,
                    actionState: Int,
                    isCurrentlyActive: Boolean
                ) {
                    super.onChildDraw(
                        c,
                        recyclerView,
                        viewHolder,
                        dX,
                        dY,
                        actionState,
                        isCurrentlyActive
                    )
                    val itemView = viewHolder.itemView
                    if (dX > 0) {
                        background.setBounds(
                            itemView.left,
                            itemView.top,
                            itemView.left + dX.toInt(),
                            itemView.bottom
                        )
                    } else if (dX < 0) {
                        background.setBounds(
                            itemView.right + dX.toInt(),
                            itemView.top,
                            itemView.right,
                            itemView.bottom
                        )
                    } else {
                        background.setBounds(0, 0, 0, 0)
                    }
                    background.draw(c)
                }
            }
        val leftTouch = ItemTouchHelper(deleteEventTouchHelperCallback)
        leftTouch.attachToRecyclerView(binding?.rvEvents)
    }

    private fun initEventsAdapter() {
        val getEvents = GetDateBasedEvents()
        getEvents.execute(getCurrentDate())
    }

    private fun initializaCalendar() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            window.statusBarColor = Color.WHITE
        }

        val myCalendarViewManager = object : CalendarViewManager {
            override fun setCalendarViewResourceId(
                position: Int,
                date: Date,
                isSelected: Boolean
            ): Int {
                val cal = Calendar.getInstance()
                cal.time = date
                return if (isSelected)
                    R.layout.selected_calendar_item
                else
                // here we return items which are not selected
                    when (cal[Calendar.DAY_OF_WEEK]) {
                        else -> R.layout.calendar_item
                    }
            }

            override fun bindDataToCalendarView(
                holder: SingleRowCalendarAdapter.CalendarViewHolder,
                date: Date,
                position: Int,
                isSelected: Boolean
            ) {
                holder.itemView.findViewById<TextView>(R.id.tv_date_calendar_item).text =
                    DateUtils.getDayNumber(date)
                holder.itemView.findViewById<TextView>(R.id.tv_day_calendar_item).text =
                    DateUtils.getDay3LettersName(date)
            }
        }
        val myCalendarChangesObserver = object : CalendarChangesObserver {
            override fun whenSelectionChanged(isSelected: Boolean, position: Int, date: Date) {
                super.whenSelectionChanged(isSelected, position, date)
            }
        }
        val mySelectionManager = object : CalendarSelectionManager {
            override fun canBeItemSelected(position: Int, date: Date): Boolean {
                val cal = Calendar.getInstance()
                cal.time = date
//                showToast(dateFormat.format(cal.time))
                val getAllEvents = GetDateBasedEvents()
                getAllEvents.execute(dateFormat.format(cal.time))
                return when (cal[Calendar.DAY_OF_WEEK]) {
                    else -> true
                }
            }
        }
        val currentDate = getCurrentDate().split("-").toTypedArray().get(0).toInt()
        val singleRowCalendar =
            findViewById<SingleRowCalendar>(R.id.main_single_row_calendar).apply {
                calendarViewManager = myCalendarViewManager
                calendarChangesObserver = myCalendarChangesObserver
                calendarSelectionManager = mySelectionManager
                setDates(getFutureDatesOfCurrentMonth())
                futureDaysCount = 30
                includeCurrentDate = true
                initialPositionIndex = currentDate - 2
                init()
                select(currentDate - 1)
            }
    }

    private fun getDatesOfNextMonth(): List<Date> {
        currentMonth++ // + because we want next month
        if (currentMonth == 12) {
            // we will switch to january of next year, when we reach last month of year
            calendar.set(Calendar.YEAR, calendar[Calendar.YEAR] + 1)
            currentMonth = 0 // 0 == january
        }
        return getDates(mutableListOf())
    }

    private fun getDatesOfPreviousMonth(): List<Date> {
        currentMonth-- // - because we want previous month
        if (currentMonth == -1) {
            // we will switch to december of previous year, when we reach first month of year
            calendar.set(Calendar.YEAR, calendar[Calendar.YEAR] - 1)
            currentMonth = 11 // 11 == december
        }
        return getDates(mutableListOf())
    }

    private fun getFutureDatesOfCurrentMonth(): List<Date> {
        // get all next dates of current month
        currentMonth = calendar[Calendar.MONTH]
        return getDates(mutableListOf())
    }

    private fun getDates(list: MutableList<Date>): List<Date> {
        // load dates of whole month
        calendar.set(Calendar.MONTH, currentMonth)
        calendar.set(Calendar.DAY_OF_MONTH, 1)
        list.add(calendar.time)
        while (currentMonth == calendar[Calendar.MONTH]) {
            calendar.add(Calendar.DATE, +1)
            if (calendar[Calendar.MONTH] == currentMonth)
                list.add(calendar.time)
        }
        calendar.add(Calendar.DATE, -1)
        return list
    }

    private fun showConfirmationDialog(position: Int) {
        AlertDialog.Builder(this)
            .setTitle("Delete Event")
            .setMessage("Do you want to delete this event?")
            .setIcon(android.R.drawable.ic_dialog_alert)
            .setPositiveButton(
                android.R.string.yes
            ) { dialog, whichButton ->
                val deleteItem = DeletePlan()
                deleteItem.execute(eventsList[position])
                eventsList.remove(eventsList[position])
                eventAdapter.notifyDataSetChanged()
                dialog.dismiss()
                showToast("Event Deleted")
            }
            .setNegativeButton(
                android.R.string.no
            ) { dialog, whichButton ->
                dialog.dismiss()
                eventAdapter.notifyDataSetChanged()
            }.show()
    }

    override fun onResume() {
        initEventsAdapter()
        initPlanAdapter()
        super.onResume()
    }
}