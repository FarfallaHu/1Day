package app.com.one.day.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import app.com.one.day.R
import app.com.one.day.models.PlanEntityModel
import app.com.one.day.utils.BottomSheetFragment
import app.com.one.day.views.activities.MainActivity
import java.util.*


class PlansAdapter(
    val planList: ArrayList<PlanEntityModel>,
    val context: Context
) :
    RecyclerView.Adapter<PlansAdapter.DisplayerViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DisplayerViewHolder {
        val itemView =
            LayoutInflater.from(parent.context).inflate(R.layout.plan_item_row, parent, false)
        return DisplayerViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: DisplayerViewHolder, position: Int) {
        val plan = planList[position]
        holder.tvPlanDesc.text = ""
        holder.tvPlanName.text = plan.name

        var array = context.getResources().getStringArray(R.array.colors)
        val color = array[Random().nextInt(array.size)]

        holder.tvEvent.text = plan.name.toString().substring(0, 2).toUpperCase()

        when (color) {
            "Blue" -> {
                holder.tvEvent.backgroundTintList =
                    ContextCompat.getColorStateList(context, R.color.blue)
            }
            "Green" -> {
                holder.tvEvent.backgroundTintList =
                    ContextCompat.getColorStateList(context, R.color.green)
            }
            "Yellow" -> {
                holder.tvEvent.backgroundTintList =
                    ContextCompat.getColorStateList(context, R.color.yellow)
            }
            "Red" -> {
                holder.tvEvent.backgroundTintList =
                    ContextCompat.getColorStateList(context, R.color.red)
            }
            "Pink" -> {
                holder.tvEvent.backgroundTintList =
                    ContextCompat.getColorStateList(context, R.color.pink)
            }
        }

        holder.itemView.setOnClickListener {
            val bottomSheetDialog = BottomSheetFragment.newInstance(plan.name)
            bottomSheetDialog.show(
                (context as MainActivity).supportFragmentManager,
                ""
            )
        }
    }

    override fun getItemCount(): Int {
        return planList.size
    }

    class DisplayerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tvPlanName: TextView = itemView.findViewById<View>(R.id.tv_eventTitle) as TextView
        var tvPlanDesc: TextView = itemView.findViewById<View>(R.id.tv_eventDesc) as TextView
        var tvEvent: TextView = itemView.findViewById<View>(R.id.tv_event) as TextView
    }
}