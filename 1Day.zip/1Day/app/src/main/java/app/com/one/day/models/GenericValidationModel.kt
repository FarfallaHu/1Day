package app.com.one.day.models

data class GenericValidationModel(var id: Int, var message: String?)