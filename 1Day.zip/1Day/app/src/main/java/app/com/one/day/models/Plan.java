package app.com.one.day.models;

public class Plan {
    public String planName, planDesc, planColor;

    public Plan() {
    }

    public Plan(String planName, String planDesc, String planColor) {
        this.planName = planName;
        this.planDesc = planDesc;
        this.planColor = planColor;
    }
}
