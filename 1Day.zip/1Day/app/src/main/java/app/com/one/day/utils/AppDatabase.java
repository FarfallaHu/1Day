package app.com.one.day.utils;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import app.com.one.day.interfaces.EventDao;
import app.com.one.day.interfaces.PlanDao;
import app.com.one.day.models.EventEntityModel;
import app.com.one.day.models.PlanEntityModel;

@Database(entities = {PlanEntityModel.class , EventEntityModel.class}, version = 3)
public abstract class AppDatabase extends RoomDatabase {
    public abstract PlanDao plansDao();
    public abstract EventDao eventDao();
}