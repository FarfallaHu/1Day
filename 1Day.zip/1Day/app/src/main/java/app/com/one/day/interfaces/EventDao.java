package app.com.one.day.interfaces;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

import app.com.one.day.models.EventEntityModel;
import app.com.one.day.models.PlanEntityModel;

@Dao
public interface EventDao {

    @Query("SELECT * FROM EventEntityModel")
    List<EventEntityModel> getAllEvents();

    @Query("SELECT * FROM EventEntityModel where eventPlan = :plan")
    List<EventEntityModel> getSpecificPlanEvents(String plan);

    @Query("SELECT * FROM EventEntityModel where eventDate = :date")
    List<EventEntityModel> getDateBasedEvents(String date);

    @Insert
    void insert(EventEntityModel event);

    @Delete
    void delete(EventEntityModel event);

    @Query("UPDATE EventEntityModel SET finished = :finished where id = :id")
    void update(boolean finished, int id);
}