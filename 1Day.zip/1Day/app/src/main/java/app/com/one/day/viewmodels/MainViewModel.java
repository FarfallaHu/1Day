package app.com.one.day.viewmodels;

import android.app.Application;

import org.jetbrains.annotations.NotNull;

public class MainViewModel extends BaseViewModel {
    public MainViewModel(@NotNull Application application) {
        super(application);
    }
}
